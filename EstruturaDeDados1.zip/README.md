# Estrutura-de-Dados-UTFPR
Conteudo de Estutura de dados segundo periodo da UTFPR em Eng. Computação
